window.onload = () => {
    document.getElementById("categories-grid").scrollIntoView({ behavior: "smooth" });
};
  




