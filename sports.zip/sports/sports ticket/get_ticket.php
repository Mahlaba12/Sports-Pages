<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Ticket</title>
    <link rel="stylesheet" href="get_ticket.css">
</head>
<body>
    
    <header>
        <h1>UJ SPORTS</h1>
        <nav>
          
          <a href="../homepage.html">Home</a>
          <a href="../bookings/bookings.html">Accommodations</a>
          <a href="#" class="self">Sports</a>
          <a href="#">Events</a>
          <a href="../music/music.html">Music</a>
        </nav>
    </header> 

        <div class="ticket">
        <h2>Sports Event Ticket</h2>
        <p><strong>Ref:</strong> <?= $ticket['reference_number'] ?></p>
        <p><strong>Name:</strong> <?= $ticket['user_name'] ?></p>
        <p><strong>Email:</strong> <?= $ticket['user_email'] ?></p>
        <p><strong>Event:</strong> <?= $ticket['event_name'] ?></p>
        <p><strong>Date:</strong> <?= $ticket['event_time'] ?></p>
        <p><strong>Venue:</strong> <?= $ticket['venue'] ?></p>
        <img src="<?= $ticket['qr_code_path'] ?>" alt="QR Code">
    </div>

<?php
require 'config.php';

if (!isset($_GET['ref'])) {
    die("No reference number provided.");
}

$ref = $_GET['ref'];


$sql = "
SELECT t.*, e.event_name, e.event_time, e.venue
FROM tickets t
JOIN events e ON t.event_id = e.id
WHERE t.reference_number = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $ref);
$stmt->execute();
$result = $stmt->get_result();
$ticket = $result->fetch_assoc();

if (!$ticket) die("Ticket not found.");

header("Content-Disposition: attachment; filename=ticket-{$ticket['reference_number']}.html");
?>


