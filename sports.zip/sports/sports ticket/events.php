<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="events.css">
</head>
<body>

    <header>
        <h1>UJ SPORTS</h1>
        <nav>
          
          <a href="../homepage.html">Home</a>
          <a href="../bookings/bookings.html">Accommodations</a>
          <a href="#" class="self">Sports</a>
          <a href="#">Events</a>
          <a href="../music/music.html">Music</a>
        </nav>
    </header> 
    
<?php
require 'config.php';

$events = $conn->query("SELECT * FROM events");

echo "<link rel='stylesheet' href='ticket.css'>";

if ($events->num_rows === 0) {
    echo "<p class='no-events'>No events available at the moment.</p>";
} else {
    while ($event = $events->fetch_assoc()) {
        echo "<div class='event-card'>
                <h3>{$event['event_name']}</h3>
                <p><strong>Date:</strong> {$event['event_time']}</p>
                <p><strong>Venue:</strong> {$event['venue']}</p>
                
                <form method='POST' action='buy_ticket.php'>
                    <input type='hidden' name='event_id' value='{$event['id']}'>
                    <input type='text' name='user_name' placeholder='Your Name' required>
                    <input type='email' name='user_email' placeholder='Your Email' required>
                    <input type='hidden' name='user_id' value='123'> <!-- From external app -->
                    <button type='submit'>Buy Ticket</button>
                </form>
              </div>";
    }
}
?>

</body>
</html>

