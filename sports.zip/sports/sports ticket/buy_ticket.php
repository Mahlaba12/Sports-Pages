<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Ticket Event</title>
    <link rel="stylesheet" href="buy_ticket.css">
</head>
<body>
    
    <header>
        <h1>UJ SPORTS</h1>
        <nav>
          
          <a href="../homepage.html">Home</a>
          <a href="../bookings/bookings.html">Accommodations</a>
          <a href="#" class="self">Sports</a>
          <a href="#">Events</a>
          <a href="../music/music.html">Music</a>
        </nav>
    </header>

<?php
require 'config.php';
require 'phpqrcode/qrlib.php';

$event_id = $_POST['event_id'];
$user_id = $_POST['user_id'];
$user_name = $_POST['user_name'];
$user_email = $_POST['user_email'];

$reference = strtoupper(uniqid("REF"));
$qrData = "Name: $user_name\nEvent ID: $event_id\nRef: $reference";

$qrPath = "qrcodes/$reference.png";
//QRcode::png($qrData, $qrPath);

$stmt = $conn->prepare("INSERT INTO tickets (user_id, user_name, user_email, event_id, reference_number, qr_code_path) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ississ", $user_id, $user_name, $user_email, $event_id, $reference, $qrPath);
$stmt->execute();

header("Location: get_ticket.php?ref=$reference");
exit;
?>

</body>
</html>
