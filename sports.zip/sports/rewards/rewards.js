function goToReward(slug) {
  window.location.href = `rewards/${slug}.html`;
}


